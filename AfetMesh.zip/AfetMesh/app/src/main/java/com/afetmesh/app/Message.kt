package com.afetmesh.app

import org.json.JSONObject

enum class MsgType { TEXT, SOS, VOICE }

/**
 * Ağda dolaşan tek mesaj birimi.
 * ttl: kalan atlama hakkı. Her cihaz iletirken 1 azaltır, 0 olunca iletilmez.
 * maxTtl: ilk gönderimdeki değer. hops = maxTtl - ttl (mesajın kaç cihaz atladığı).
 */
data class Message(
    val id: String,
    val from: String,
    val to: String, // boş = herkese
    val type: MsgType,
    val text: String,
    val lat: Double?,
    val lon: Double?,
    val battery: Int,
    val ttl: Int,
    val maxTtl: Int,
    val time: Long,
    val audio: String? = null, // VOICE için: Base64 AMR-NB
) {
    val hops: Int get() = maxTtl - ttl

    fun toBytes(): ByteArray = JSONObject().apply {
        put("i", id)
        put("f", from)
        put("t", to)
        put("y", type.name)
        put("x", text)
        if (lat != null && lon != null) {
            put("la", lat)
            put("lo", lon)
        }
        put("b", battery)
        put("l", ttl)
        put("m", maxTtl)
        put("ts", time)
        if (audio != null) put("a", audio)
    }.toString().toByteArray(Charsets.UTF_8)

    companion object {
        fun fromBytes(bytes: ByteArray): Message? = try {
            val o = JSONObject(String(bytes, Charsets.UTF_8))
            Message(
                id = o.getString("i"),
                from = o.getString("f"),
                to = o.getString("t"),
                type = MsgType.valueOf(o.getString("y")),
                text = o.getString("x"),
                lat = if (o.has("la")) o.getDouble("la") else null,
                lon = if (o.has("lo")) o.getDouble("lo") else null,
                battery = o.getInt("b"),
                ttl = o.getInt("l"),
                maxTtl = o.getInt("m"),
                time = o.getLong("ts"),
                audio = if (o.has("a")) o.getString("a") else null,
            )
        } catch (e: Exception) {
            null
        }
    }
}
