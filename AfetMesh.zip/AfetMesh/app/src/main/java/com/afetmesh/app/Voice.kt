package com.afetmesh.app

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.util.Base64
import android.widget.Toast
import java.io.File

/**
 * Kısa sesli not kaydı. AMR-NB 4.75 kbps: 10 sn yaklaşık 6 KB.
 * Bu boyut Nearby bayt paketine (32 KB) ve çoklu atlamaya uygundur.
 */
class VoiceRecorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private val file = File(ctx.cacheDir, "rec.amr")

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()

    fun start() {
        val r = newRecorder()
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.AMR_NB)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
            r.setAudioSamplingRate(8000)
            r.setAudioEncodingBitRate(4750)
            r.setMaxDuration(10_000)
            r.setOutputFile(file.absolutePath)
            r.prepare()
            r.start()
            rec = r
        } catch (e: Exception) {
            r.release()
            throw e
        }
    }

    /** Kaydı bitirir; ses baytlarını döndürür (hata olursa null). */
    fun stop(): ByteArray? {
        val r = rec ?: return null
        rec = null
        return try {
            r.stop()
            r.release()
            file.readBytes()
        } catch (e: Exception) {
            r.release()
            null
        }
    }
}

object VoicePlayer {
    private var player: MediaPlayer? = null

    fun play(ctx: Context, base64: String) {
        try {
            val f = File(ctx.cacheDir, "play.amr")
            f.writeBytes(Base64.decode(base64, Base64.NO_WRAP))
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(f.absolutePath)
                setOnCompletionListener {
                    it.release()
                    if (player === it) player = null
                }
                prepare()
                start()
            }
        } catch (e: Exception) {
            Toast.makeText(ctx, "Ses oynatılamadı", Toast.LENGTH_SHORT).show()
        }
    }
}
