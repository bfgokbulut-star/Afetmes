package com.afetmesh.app

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

/** Servis ile arayüz arasındaki ortak durum. */
object MeshState {
    val messages = MutableStateFlow<List<Message>>(emptyList())
    val peerCount = MutableStateFlow(0)
    val running = MutableStateFlow(false)
    val sosActive = MutableStateFlow(false)
    val status = MutableStateFlow("Durduruldu")
    val quakeEnabled = MutableStateFlow(true)

    private var loaded = false

    @Volatile
    var myCode: String = ""

    fun ensureCode(ctx: Context): String {
        if (!loaded) {
            val sp = ctx.applicationContext.getSharedPreferences("mesh", Context.MODE_PRIVATE)
            val saved = sp.getString("code", null)
            myCode = saved ?: generateCode().also { sp.edit().putString("code", it).apply() }
            quakeEnabled.value = sp.getBoolean("quake", true)
            loaded = true
        }
        return myCode
    }

    fun setQuake(ctx: Context, enabled: Boolean) {
        ctx.applicationContext.getSharedPreferences("mesh", Context.MODE_PRIVATE)
            .edit().putBoolean("quake", enabled).apply()
        quakeEnabled.value = enabled
    }

    private fun generateCode(): String {
        // 0/O ve 1/I gibi karışan karakterler yok
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return (1..6).map { alphabet.random() }.joinToString("")
    }

    fun add(m: Message) {
        messages.update { list ->
            // Aynı kişinin eski SOS'u yenisiyle değişir (liste şişmesin)
            val base = if (m.type == MsgType.SOS) {
                list.filterNot { it.type == MsgType.SOS && it.from == m.from }
            } else list
            (base + m).takeLast(500)
        }
    }
}
