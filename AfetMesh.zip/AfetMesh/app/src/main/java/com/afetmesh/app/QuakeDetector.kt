package com.afetmesh.app

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Basit deprem sezgisi (heuristic). Yanlış alarm üretebilir, sahada ayarlanmalıdır.
 *
 * Mantık (1 sn'lik kovalar):
 *  - "Durağan" kova: ivme ortalama sapması çok küçük (telefon masada/şarjda).
 *  - "Sarsıntı" kova: belirgin ve sürekli sarsıntı.
 *  - En az STILL_NEEDED sn durağan kaldıktan sonra, yerçekimi yönü neredeyse değişmeden
 *    (telefon elde taşınmıyor, yerinde sarsılıyor) ardışık SHAKE_BUCKETS sn sarsıntı olursa tetiklenir.
 *  - Tetiklendikten sonra COOLDOWN_MS boyunca tekrar tetiklenmez.
 */
class QuakeDetector(private val onQuake: () -> Unit) : SensorEventListener {

    private companion object {
        const val G = 9.81
        const val STILL_MEAN = 0.3
        const val SHAKE_MEAN = 0.8
        const val SHAKE_MAX = 2.0
        const val STILL_NEEDED = 5
        const val SHAKE_BUCKETS = 3
        const val MIN_COS = 0.94 // yerçekimi yönü en fazla ~20° değişebilir
        const val COOLDOWN_MS = 10 * 60_000L
        const val BUCKET_MS = 1000L
    }

    private var bucketStart = 0L
    private var n = 0
    private var sx = 0.0
    private var sy = 0.0
    private var sz = 0.0
    private var sumDev = 0.0
    private var maxDev = 0.0

    private var still = 0
    private var shake = 0
    private var base: DoubleArray? = null
    private var lastTrigger = -COOLDOWN_MS

    override fun onSensorChanged(e: SensorEvent) {
        val x = e.values[0].toDouble()
        val y = e.values[1].toDouble()
        val z = e.values[2].toDouble()
        val now = e.timestamp / 1_000_000L // ns -> ms
        if (n == 0) bucketStart = now

        val dev = abs(sqrt(x * x + y * y + z * z) - G)
        sx += x; sy += y; sz += z
        sumDev += dev
        if (dev > maxDev) maxDev = dev
        n++

        if (now - bucketStart >= BUCKET_MS) {
            endBucket(now)
            n = 0; sx = 0.0; sy = 0.0; sz = 0.0; sumDev = 0.0; maxDev = 0.0
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun endBucket(now: Long) {
        val mx = sx / n
        val my = sy / n
        val mz = sz / n
        val mean = sumDev / n
        when {
            mean < STILL_MEAN -> {
                still++
                shake = 0
                base = doubleArrayOf(mx, my, mz)
            }
            mean > SHAKE_MEAN && maxDev > SHAKE_MAX -> {
                val b = base
                if (still >= STILL_NEEDED && b != null && cosBetween(b, mx, my, mz) > MIN_COS) {
                    shake++
                    if (shake >= SHAKE_BUCKETS && now - lastTrigger > COOLDOWN_MS) {
                        lastTrigger = now
                        shake = 0
                        still = 0
                        onQuake()
                    }
                } else {
                    // Telefon elde/hareket halinde: deprem değil
                    shake = 0
                    still = 0
                }
            }
            else -> shake = 0 // ara değer: sarsıntı serisini kes, durağanlığı koru
        }
    }

    private fun cosBetween(b: DoubleArray, x: Double, y: Double, z: Double): Double {
        val dot = b[0] * x + b[1] * y + b[2] * z
        val nb = sqrt(b[0] * b[0] + b[1] * b[1] + b[2] * b[2])
        val nm = sqrt(x * x + y * y + z * z)
        return if (nb == 0.0 || nm == 0.0) 0.0 else dot / (nb * nm)
    }
}
